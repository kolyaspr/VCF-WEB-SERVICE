import os
from flask import Flask, request, render_template, redirect, url_for, send_from_directory, send_file, jsonify, flash
import vobject
import quopri
import csv

#шифрование файла
# pip install pycryptodome

from Crypto.Cipher import AES
from Crypto.Util import Padding

def encrypt_file(file_path, password):
    key = password.encode('utf-8')
    iv = os.urandom(16)
    cipher = AES.new(key, AES.MODE_CBC, iv)
    with open(file_path, 'rb') as file:
        data = file.read()
    padded_data = Padding.pad(data, AES.block_size)
    encrypted_data = cipher.encrypt(padded_data)
    encrypted_file_data = iv + encrypted_data
    with open(file_path, 'wb') as file:
        file.write(encrypted_file_data)



app = Flask(__name__)
app.secret_key = 'my_secret_key'

# app = Flask(__name__, template_folder='path/to/your/templates')
# Замените 'path/to/your/templates' на путь к директории, где находятся ваши шаблоны


contacts = []  # Глобальный список контактов


@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_vcf():
    file = request.files['file']
    file_content = file.stream.read()  # Читаем содержимое файла в байтах

    # Используем UTF-8 для декодирования
    decoded_content = quopri.decodestring(file_content).decode('utf-8')
    vcards = vobject.readComponents(decoded_content)
    global contacts
    contacts = []
    for vcard in vcards:
        name = vcard.fn.value if hasattr(vcard, 'fn') else 'Имя отсутствует'
        phone = vcard.tel.value if hasattr(vcard, 'tel') else 'Номер отсутствует'
        contacts.append({'name': name, 'phone': phone})
    return render_template('contacts.html', contacts=contacts)

@app.route('/contacts')
def contacts():
    return render_template('contacts.html', contacts=contacts)



#ИЗМЕНЕНИЕ УДАЛЕНИЕ ДОБАВЛЕНИЕ

#добавить
@app.route('/add-contact', methods=['POST'])
def add_contact():
    name = request.form['name']
    phone = request.form['phone']
    contacts.append({'name': name, 'phone': phone})
    return redirect(url_for('contacts'))

#изменить
@app.route('/edit-contact/<int:contact_index>', methods=['GET', 'POST'])
def edit_contact(contact_index):
    if request.method == 'GET':
        contact = contacts[contact_index]
        return render_template('edit_contact.html', contact=contact, contact_index=contact_index)
    elif request.method == 'POST':
        contacts[contact_index]['name'] = request.form['name']
        contacts[contact_index]['phone'] = request.form['phone']
        flash('Контакт успешно изменен.')
        return redirect(url_for('contacts'))

#удалить
@app.route('/delete-contact/<int:contact_index>', methods=['POST'])
def delete_contact(contact_index):
    del contacts[contact_index]
    flash('Контакт успешно удален.')
    return redirect(url_for('contacts'))








#экспорт csv

@app.route('/export-csv', methods=['GET'])
def export_csv():
    csv_filename = 'contacts.csv'
    csv_path = os.path.join(app.root_path, csv_filename)
    
    with open(csv_path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(['Имя', 'Телефон'])
        for contact in contacts:
            writer.writerow([contact['name'], contact['phone']])
    
    return send_file(csv_path, as_attachment=True)



#экспорт vcf

@app.route('/export-vcf', methods=['GET'])
def export_vcf():
    vcard_list = []
    
    for contact in contacts:
        vcard = vobject.vCard()
        vcard.add('fn').value = contact['name']
        vcard.add('tel').value = contact['phone']
        vcard_list.append(vcard)

    vcf_data = ''.join([vcard.serialize() for vcard in vcard_list])
    
    response = app.response_class(
        vcf_data,
        mimetype='text/vcard',
        headers={'Content-Disposition': 'attachment; filename="contacts.vcf"'}
    )
    
    return response


# поиск/фильтрацию в содержимом файла .vcf

@app.route('/search', methods=['GET'])
def search_contacts():
    search_query = request.args.get('query')  # Получаем параметр запроса 'query'

    if not search_query:
        return jsonify({'error': 'Параметр "query" отсутствует в запросе'}), 400

    filtered_contacts = []
    for contact in contacts:
        # Проверяем, содержит ли контакт имя или номер телефона подстроку поискового запроса
        if (search_query.lower() in contact['name'].lower()) or (search_query in contact['phone']):
            filtered_contacts.append(contact)

    return jsonify({'contacts': filtered_contacts}), 200



if __name__ == '__main__':
    app.run(debug=True)
